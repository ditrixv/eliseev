-- Adminer 4.2.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(39,	'2014_10_12_000000_create_users_table',	1),
(40,	'2014_10_12_100000_create_password_resets_table',	1),
(41,	'2021_08_14_175406_add_user_verification',	1),
(42,	'2021_08_20_172759_add_user_role',	1),
(43,	'2021_08_22_081554_create_regions_table',	1);

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `regions`;
CREATE TABLE `regions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `regions_parent_id_slug_unique` (`parent_id`,`slug`),
  UNIQUE KEY `regions_parent_id_name_unique` (`parent_id`,`name`),
  KEY `regions_name_index` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `regions` (`id`, `name`, `slug`, `parent_id`, `created_at`, `updated_at`) VALUES
(1,	'Kuhntown',	'kuhntown',	NULL,	'2021-08-22 19:46:33',	'2021-08-22 19:46:33'),
(2,	'Willfurt',	'willfurt',	NULL,	'2021-08-22 19:46:33',	'2021-08-22 19:46:33'),
(3,	'East Earlineville',	'east-earlineville',	NULL,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(4,	'Bodetown',	'bodetown',	NULL,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(5,	'Port Lilianeshire',	'port-lilianeshire',	NULL,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(6,	'Kuvalisfort',	'kuvalisfort',	NULL,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(7,	'Candidohaven',	'candidohaven',	NULL,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(8,	'Port Morgan',	'port-morgan',	NULL,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(9,	'Lindastad',	'lindastad',	NULL,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(10,	'Raynorport',	'raynorport',	NULL,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(11,	'South Marquis',	'south-marquis',	2,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(12,	'Sipesmouth',	'sipesmouth',	2,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(13,	'Considinemouth',	'considinemouth',	2,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(14,	'Johnsonbury',	'johnsonbury',	8,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(15,	'Harrisonfort',	'harrisonfort',	8,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(16,	'North Astrid',	'north-astrid',	8,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(17,	'Margretfort',	'margretfort',	8,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(18,	'New Dariana',	'new-dariana',	8,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(19,	'West Birdie',	'west-birdie',	8,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(20,	'Corinestad',	'corinestad',	16,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(21,	'East Rebeccaton',	'east-rebeccaton',	16,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(22,	'Betteton',	'betteton',	16,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(23,	'New Alfredaland',	'new-alfredaland',	5,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(24,	'Kianaside',	'kianaside',	5,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(25,	'Hartmannport',	'hartmannport',	5,	'2021-08-22 19:46:34',	'2021-08-22 19:46:34'),
(26,	'Maidachester',	'maidachester',	5,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(27,	'West Corneliusmouth',	'west-corneliusmouth',	5,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(28,	'West Alejandra',	'west-alejandra',	5,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(29,	'New Medaville',	'new-medaville',	5,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(30,	'New Andystad',	'new-andystad',	25,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(31,	'Aracelyport',	'aracelyport',	25,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(32,	'Cloydhaven',	'cloydhaven',	25,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(33,	'Bodeburgh',	'bodeburgh',	25,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(34,	'Franciscohaven',	'franciscohaven',	6,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(35,	'North Brenden',	'north-brenden',	6,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(36,	'West Adolphus',	'west-adolphus',	6,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(37,	'West Estrellaborough',	'west-estrellaborough',	6,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(38,	'North Amira',	'north-amira',	6,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(39,	'Walshbury',	'walshbury',	6,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(40,	'Delphamouth',	'delphamouth',	35,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(41,	'Denesikville',	'denesikville',	35,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(42,	'Estellefurt',	'estellefurt',	35,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(43,	'Port Burleyhaven',	'port-burleyhaven',	37,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(44,	'Larsonmouth',	'larsonmouth',	37,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(45,	'Ilafort',	'ilafort',	37,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(46,	'New Isobelmouth',	'new-isobelmouth',	37,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(47,	'Shaniaport',	'shaniaport',	37,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(48,	'Evertstad',	'evertstad',	10,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(49,	'West Orinhaven',	'west-orinhaven',	10,	'2021-08-22 19:46:35',	'2021-08-22 19:46:35'),
(50,	'Jonesville',	'jonesville',	10,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(51,	'Port Conniefurt',	'port-conniefurt',	48,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(52,	'Batzstad',	'batzstad',	48,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(53,	'Ceasarport',	'ceasarport',	48,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(54,	'North Effieshire',	'north-effieshire',	48,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(55,	'Lake Hannaburgh',	'lake-hannaburgh',	48,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(56,	'Lockmanbury',	'lockmanbury',	48,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(57,	'South Jamisonstad',	'south-jamisonstad',	48,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(58,	'Oberbrunnerfort',	'oberbrunnerfort',	48,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(59,	'Ardellaville',	'ardellaville',	48,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(60,	'Port Savion',	'port-savion',	48,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(61,	'South Chauncey',	'south-chauncey',	49,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(62,	'West Kodymouth',	'west-kodymouth',	49,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(63,	'Gerlachhaven',	'gerlachhaven',	49,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(64,	'South Antoinetteport',	'south-antoinetteport',	49,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(65,	'South Brandyn',	'south-brandyn',	49,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(66,	'North Coraview',	'north-coraview',	50,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(67,	'Lake Devan',	'lake-devan',	50,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(68,	'Rosemarieshire',	'rosemarieshire',	50,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(69,	'Lake Enriquechester',	'lake-enriquechester',	50,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(70,	'New Lylachester',	'new-lylachester',	50,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(71,	'East Tryciamouth',	'east-tryciamouth',	50,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(72,	'West Philip',	'west-philip',	50,	'2021-08-22 19:46:36',	'2021-08-22 19:46:36'),
(73,	'Romabury',	'romabury',	50,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(74,	'Humbertofurt',	'humbertofurt',	50,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(75,	'South Ernestside',	'south-ernestside',	50,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(76,	'New Miguel',	'new-miguel',	40,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(77,	'New Lewiston',	'new-lewiston',	40,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(78,	'Baileytown',	'baileytown',	40,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(79,	'Briellehaven',	'briellehaven',	40,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(80,	'South Janashire',	'south-janashire',	40,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(81,	'North Freda',	'north-freda',	20,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(82,	'New Brandyn',	'new-brandyn',	20,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(83,	'Earltown',	'earltown',	20,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(84,	'Albaberg',	'albaberg',	20,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(85,	'O\'Keefeborough',	'okeefeborough',	25,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(86,	'Johannaborough',	'johannaborough',	25,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(87,	'West Winifredmouth',	'west-winifredmouth',	25,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(88,	'Lake Rosalia',	'lake-rosalia',	25,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(89,	'Esperanzaton',	'esperanzaton',	25,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(90,	'New Reggie',	'new-reggie',	25,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(91,	'Turcotteborough',	'turcotteborough',	25,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(92,	'Cornellport',	'cornellport',	27,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(93,	'South Kamrenmouth',	'south-kamrenmouth',	27,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(94,	'Leannontown',	'leannontown',	27,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(95,	'New Savanahmouth',	'new-savanahmouth',	27,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(96,	'South Huberthaven',	'south-huberthaven',	27,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(97,	'North Caitlyn',	'north-caitlyn',	27,	'2021-08-22 19:46:37',	'2021-08-22 19:46:37'),
(98,	'Leschshire',	'leschshire',	14,	'2021-08-22 19:46:38',	'2021-08-22 19:46:38'),
(99,	'Lockmanfort',	'lockmanfort',	14,	'2021-08-22 19:46:38',	'2021-08-22 19:46:38'),
(100,	'Rippinhaven',	'rippinhaven',	14,	'2021-08-22 19:46:38',	'2021-08-22 19:46:38');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `verify_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_verify_token_unique` (`verify_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `status`, `verify_token`, `role`) VALUES
(1,	'Mr. Nathanael Hayes',	'tjohns@example.net',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'HRnf33r5Gr',	'2021-08-22 19:46:32',	'2021-08-22 19:46:32',	'wait',	'3518b632-f36f-4c7b-ac59-e96b2e335207',	'user'),
(2,	'Arturo Kuvalis',	'oswald15@example.com',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'3qrHp3vlJd',	'2021-08-22 19:46:32',	'2021-08-22 19:46:32',	'wait',	'10807530-b552-4407-91df-17ea497348d6',	'user'),
(3,	'Velma Denesik',	'retha44@example.com',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'5u2loNxhNV',	'2021-08-22 19:46:32',	'2021-08-22 19:46:32',	'wait',	'b894c331-78af-4233-b80e-a97db450d027',	'user'),
(4,	'Katelyn Dickinson',	'dibbert.cleo@example.net',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'dM9ihJlKqk',	'2021-08-22 19:46:32',	'2021-08-22 19:46:32',	'wait',	'7689f727-b766-4665-9680-3df34a6ea916',	'user'),
(5,	'Prof. Celestino Lubowitz',	'marisol68@example.org',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'btKS1jGx2G',	'2021-08-22 19:46:32',	'2021-08-22 19:46:32',	'active',	NULL,	'user'),
(6,	'Jennifer Boyle',	'trohan@example.com',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'ICkUX9si36',	'2021-08-22 19:46:32',	'2021-08-22 19:46:32',	'active',	NULL,	'user'),
(7,	'Sylvia Konopelski IV',	'jett.schinner@example.net',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'vyBJkvu5hx',	'2021-08-22 19:46:33',	'2021-08-22 19:46:33',	'wait',	'2754540b-023a-4bec-a5f3-a7dfc4e21957',	'user'),
(8,	'Bill Beer',	'ilene.pollich@example.com',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'KoVeUK05xa',	'2021-08-22 19:46:33',	'2021-08-22 19:46:33',	'wait',	'54097f8f-3dcc-4432-86ca-390353669c22',	'user'),
(9,	'Berenice Hand MD',	'velda.berge@example.com',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'7X85QcBgRt',	'2021-08-22 19:46:33',	'2021-08-22 19:46:33',	'wait',	'8c9658de-d342-43ca-934f-5e3ccc3bbd9f',	'user'),
(10,	'Krista Champlin',	'jacobi.brian@example.org',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'p2vhR6KTmi',	'2021-08-22 19:46:33',	'2021-08-22 19:46:33',	'active',	NULL,	'user'),
(11,	'Henri Kassulke',	'jay33@example.com',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'DuDxc0rIxH',	'2021-08-22 19:46:33',	'2021-08-22 19:46:33',	'wait',	'19582114-80ea-4224-8521-92eba705084a',	'user'),
(12,	'Emery Kautzer',	'kdavis@example.net',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'KvNAIt45kp',	'2021-08-22 19:46:33',	'2021-08-22 19:46:33',	'active',	NULL,	'user'),
(13,	'Mrs. Sharon Runte IV',	'kstehr@example.com',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'4D5QtSWLjU',	'2021-08-22 19:46:33',	'2021-08-22 19:46:33',	'wait',	'aacf3b0a-abb2-4df0-a388-8bef004bd4a1',	'user'),
(14,	'Danial Durgan',	'moder@example.net',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'WDSKYPlYu2',	'2021-08-22 19:46:33',	'2021-08-22 19:48:31',	'active',	NULL,	'moderator'),
(15,	'Mr. Kyleigh Lebsack',	'hobart53@example.com',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'x8W3k2nfdI',	'2021-08-22 19:46:33',	'2021-08-22 19:46:33',	'active',	NULL,	'user'),
(17,	'Ena Torphy',	'kelly.erdman@example.org',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'lOQgNcbnEQ',	'2021-08-22 19:46:33',	'2021-08-22 19:46:33',	'wait',	'1b71ae53-4e01-4f77-9028-6fd3ddc98497',	'user'),
(18,	'Cecelia Runolfsson',	'buckridge.lesley@example.com',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'VW7MRjsclb',	'2021-08-22 19:46:33',	'2021-08-22 19:46:33',	'active',	NULL,	'user'),
(19,	'Ivy Fahey MD',	'lang.shawn@example.net',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'ZPGcwVDPt0',	'2021-08-22 19:46:33',	'2021-08-22 19:46:33',	'active',	NULL,	'user'),
(20,	'Davion Moore',	'obechtelar@example.net',	'$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm',	'cig3P6R3CS',	'2021-08-22 19:46:33',	'2021-08-22 19:46:33',	'wait',	'17232c4d-627c-4140-be1f-1a714144fe6c',	'user'),
(21,	'Ditrix',	'admin@mail.com',	'$2y$10$EiuMUvdwneYMHsDdhvMXKuR8VXfxljMNRzV38N8jg2UYx7Ln9xsIe',	NULL,	'2021-08-22 19:47:03',	'2021-08-22 19:47:53',	'active',	NULL,	'admin');

-- 2021-08-22 20:01:18
